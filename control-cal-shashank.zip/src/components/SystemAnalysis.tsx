import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { TrendingUp } from 'lucide-react';

interface Complex {
  real: number;
  imaginary: number;
}

interface SystemAnalysisProps {
  poles: Complex[];
  zeros: Complex[];
  dcGain: number;
  isStable: boolean;
  systemType: number;
  systemOrder: number;
  steadyStateErrors: {
    step: number;
    ramp: number;
    parabolic: number;
  };
}

const formatComplex = (complex: Complex): string => {
  if (Math.abs(complex.imaginary) < 1e-10) {
    return complex.real.toFixed(4);
  }
  const sign = complex.imaginary >= 0 ? '+' : '-';
  return `${complex.real.toFixed(4)} ${sign} ${Math.abs(complex.imaginary).toFixed(4)}j`;
};

const SystemAnalysis: React.FC<SystemAnalysisProps> = ({
  poles,
  zeros,
  dcGain,
  isStable,
  systemType,
  systemOrder,
  steadyStateErrors
}) => {
  return (
    <Card className="p-6 shadow-medium border-border/50">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <TrendingUp className="h-5 w-5 text-primary" />
        System Analysis
      </h2>
      
      <div className="grid md:grid-cols-2 gap-6">
        {/* System Properties */}
        <div className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">System Properties</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">DC Gain:</span>
                <span className="font-mono">
                  {isFinite(dcGain) ? dcGain.toFixed(4) : '∞'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">System Order:</span>
                <Badge variant="outline">{systemOrder}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">System Type:</span>
                <Badge variant="outline">Type {systemType}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Stability:</span>
                <Badge 
                  variant={isStable ? "default" : "destructive"}
                  className={isStable ? "bg-secondary" : ""}
                >
                  {isStable ? 'Stable' : 'Unstable'}
                </Badge>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-medium mb-2">Steady-State Errors</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Step Input (e_ss):</span>
                <span className="font-mono text-sm">
                  {isFinite(steadyStateErrors.step) ? steadyStateErrors.step.toFixed(4) : '∞'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Ramp Input (e_ss):</span>
                <span className="font-mono text-sm">
                  {isFinite(steadyStateErrors.ramp) ? steadyStateErrors.ramp.toFixed(4) : '∞'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Parabolic Input (e_ss):</span>
                <span className="font-mono text-sm">
                  {isFinite(steadyStateErrors.parabolic) ? steadyStateErrors.parabolic.toFixed(4) : '∞'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Poles and Zeros */}
        <div className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">Poles</h3>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {poles.length > 0 ? (
                poles.map((pole, index) => (
                  <div key={index} className="text-sm font-mono bg-muted/30 p-2 rounded">
                    {formatComplex(pole)}
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No poles found</p>
              )}
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-medium mb-2">Zeros</h3>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {zeros.length > 0 ? (
                zeros.map((zero, index) => (
                  <div key={index} className="text-sm font-mono bg-muted/30 p-2 rounded">
                    {formatComplex(zero)}
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No zeros found</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default SystemAnalysis;