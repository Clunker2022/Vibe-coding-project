import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Gauge } from 'lucide-react';

interface AdvancedAnalysisProps {
  gainMargin: number;
  phaseMargin: number;
  bandwidth: number;
  peakOvershoot: number;
  settlingTime: number;
  riseTime: number;
  naturalFrequency: number;
  dampingRatio: number;
  resonantFrequency: number;
  resonantPeak: number;
  isMinimumPhase: boolean;
}

const AdvancedAnalysis: React.FC<AdvancedAnalysisProps> = ({
  gainMargin,
  phaseMargin,
  bandwidth,
  peakOvershoot,
  settlingTime,
  riseTime,
  naturalFrequency,
  dampingRatio,
  resonantFrequency,
  resonantPeak,
  isMinimumPhase
}) => {
  const getStabilityStatus = () => {
    if (gainMargin > 6 && phaseMargin > 45) return { status: 'Excellent', variant: 'default' as const };
    if (gainMargin > 3 && phaseMargin > 30) return { status: 'Good', variant: 'default' as const };
    if (gainMargin > 1 && phaseMargin > 0) return { status: 'Marginal', variant: 'secondary' as const };
    return { status: 'Poor', variant: 'destructive' as const };
  };

  const getDampingType = () => {
    if (dampingRatio > 1) return 'Overdamped';
    if (dampingRatio === 1) return 'Critically Damped';
    if (dampingRatio > 0) return 'Underdamped';
    return 'Unstable';
  };

  const stabilityStatus = getStabilityStatus();

  return (
    <Card className="p-6 shadow-medium border-border/50">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Gauge className="h-5 w-5 text-primary" />
        Advanced Analysis
      </h2>
      
      <div className="space-y-6">
        {/* Stability Margins */}
        <div>
          <h3 className="font-medium mb-3">Stability Margins</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Gain Margin:</span>
                <span className="font-mono">
                  {isFinite(gainMargin) ? `${gainMargin.toFixed(2)} dB` : '∞'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Phase Margin:</span>
                <span className="font-mono">
                  {isFinite(phaseMargin) ? `${phaseMargin.toFixed(2)}°` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Stability:</span>
                <Badge variant={stabilityStatus.variant}>
                  {stabilityStatus.status}
                </Badge>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Bandwidth:</span>
                <span className="font-mono">
                  {isFinite(bandwidth) ? `${bandwidth.toFixed(3)} rad/s` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Resonant Peak:</span>
                <span className="font-mono">
                  {isFinite(resonantPeak) ? `${resonantPeak.toFixed(2)} dB` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Phase Type:</span>
                <Badge variant="outline">
                  {isMinimumPhase ? 'Minimum Phase' : 'Non-Minimum Phase'}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        <Separator />

        {/* Time Domain Characteristics */}
        <div>
          <h3 className="font-medium mb-3">Time Domain Characteristics</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Peak Overshoot:</span>
                <span className="font-mono">
                  {isFinite(peakOvershoot) ? `${peakOvershoot.toFixed(2)}%` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Settling Time (2%):</span>
                <span className="font-mono">
                  {isFinite(settlingTime) ? `${settlingTime.toFixed(3)} s` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Rise Time:</span>
                <span className="font-mono">
                  {isFinite(riseTime) ? `${riseTime.toFixed(3)} s` : 'N/A'}
                </span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Natural Frequency:</span>
                <span className="font-mono">
                  {isFinite(naturalFrequency) ? `${naturalFrequency.toFixed(3)} rad/s` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Damping Ratio:</span>
                <span className="font-mono">
                  {isFinite(dampingRatio) ? dampingRatio.toFixed(4) : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Damping Type:</span>
                <Badge variant="outline">
                  {getDampingType()}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        <Separator />

        {/* Frequency Domain Characteristics */}
        <div>
          <h3 className="font-medium mb-3">Frequency Domain Characteristics</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Resonant Frequency:</span>
                <span className="font-mono">
                  {isFinite(resonantFrequency) ? `${resonantFrequency.toFixed(3)} rad/s` : 'N/A'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Guidelines */}
        <div className="bg-muted/20 p-4 rounded-lg">
          <h4 className="text-sm font-medium mb-2">Performance Guidelines:</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Gain Margin &gt; 6 dB and Phase Margin &gt; 45° for excellent stability</li>
            <li>• Damping ratio 0.4-0.8 for good transient response</li>
            <li>• Lower bandwidth means slower response but better noise rejection</li>
            <li>• Peak overshoot &lt; 20% generally acceptable for most applications</li>
          </ul>
        </div>
      </div>
    </Card>
  );
};

export default AdvancedAnalysis;