import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { GitBranch, RotateCcw } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface Complex {
  real: number;
  imaginary: number;
}

interface LoopAnalysisProps {
  openLoop: {
    poles: Complex[];
    zeros: Complex[];
    dcGain: number;
    isStable: boolean;
    frequencyResponse: Array<{
      frequency: number;
      magnitude: number;
      magnitudeDb: number;
      phase: number;
    }>;
    timeResponse: {
      step: Array<{ time: number; amplitude: number; }>;
      impulse: Array<{ time: number; amplitude: number; }>;
    };
  };
  closedLoop: {
    poles: Complex[];
    zeros: Complex[];
    dcGain: number;
    isStable: boolean;
    frequencyResponse: Array<{
      frequency: number;
      magnitude: number;
      magnitudeDb: number;
      phase: number;
    }>;
    timeResponse: {
      step: Array<{ time: number; amplitude: number; }>;
      impulse: Array<{ time: number; amplitude: number; }>;
    };
    bandwidth: number;
    peakOvershoot: number;
    settlingTime: number;
    riseTime: number;
  };
}

const formatComplex = (complex: Complex): string => {
  if (Math.abs(complex.imaginary) < 1e-10) {
    return complex.real.toFixed(4);
  }
  const sign = complex.imaginary >= 0 ? '+' : '-';
  return `${complex.real.toFixed(4)} ${sign} ${Math.abs(complex.imaginary).toFixed(4)}j`;
};

const LoopAnalysis: React.FC<LoopAnalysisProps> = ({ openLoop, closedLoop }) => {
  // Combine frequency responses for comparison
  const combinedFreqResponse = openLoop.frequencyResponse.map((point, index) => ({
    frequency: point.frequency,
    openMagnitudeDb: point.magnitudeDb,
    closedMagnitudeDb: closedLoop.frequencyResponse[index]?.magnitudeDb || 0,
    openPhase: point.phase,
    closedPhase: closedLoop.frequencyResponse[index]?.phase || 0
  }));

  // Combine time responses for comparison
  const combinedStepResponse = openLoop.timeResponse.step.map((point, index) => ({
    time: point.time,
    openStep: point.amplitude,
    closedStep: closedLoop.timeResponse.step[index]?.amplitude || 0
  }));

  const combinedImpulseResponse = openLoop.timeResponse.impulse.map((point, index) => ({
    time: point.time,
    openImpulse: point.amplitude,
    closedImpulse: closedLoop.timeResponse.impulse[index]?.amplitude || 0
  }));

  return (
    <div className="space-y-6">
      {/* Summary Comparison */}
      <Card className="p-6 shadow-medium border-border/50">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <GitBranch className="h-5 w-5 text-primary" />
          Open Loop vs Closed Loop Analysis
        </h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Open Loop Summary */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-3">
              <RotateCcw className="h-4 w-4 text-secondary" />
              <h3 className="font-medium">Open Loop System G(s)</h3>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">DC Gain:</span>
                <span className="font-mono text-sm">
                  {isFinite(openLoop.dcGain) ? openLoop.dcGain.toFixed(4) : '∞'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Poles:</span>
                <span className="text-sm">{openLoop.poles.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Zeros:</span>
                <span className="text-sm">{openLoop.zeros.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Stability:</span>
                <Badge 
                  variant={openLoop.isStable ? "default" : "destructive"}
                  className={openLoop.isStable ? "bg-secondary" : ""}
                >
                  {openLoop.isStable ? 'Stable' : 'Unstable'}
                </Badge>
              </div>
            </div>
          </div>

          {/* Closed Loop Summary */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-3">
              <GitBranch className="h-4 w-4 text-primary" />
              <h3 className="font-medium">Closed Loop System T(s)</h3>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">DC Gain:</span>
                <span className="font-mono text-sm">
                  {isFinite(closedLoop.dcGain) ? closedLoop.dcGain.toFixed(4) : '∞'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Bandwidth:</span>
                <span className="font-mono text-sm">
                  {isFinite(closedLoop.bandwidth) ? `${closedLoop.bandwidth.toFixed(3)} rad/s` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Peak Overshoot:</span>
                <span className="font-mono text-sm">
                  {isFinite(closedLoop.peakOvershoot) ? `${closedLoop.peakOvershoot.toFixed(2)}%` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Stability:</span>
                <Badge 
                  variant={closedLoop.isStable ? "default" : "destructive"}
                  className={closedLoop.isStable ? "bg-secondary" : ""}
                >
                  {closedLoop.isStable ? 'Stable' : 'Unstable'}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-4" />

        {/* Key Differences */}
        <div className="bg-muted/20 p-4 rounded-lg">
          <h4 className="text-sm font-medium mb-2">Key Insights:</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Closed loop system: T(s) = G(s) / (1 + G(s)) for unity feedback</li>
            <li>• Feedback typically improves stability and reduces steady-state error</li>
            <li>• Closed loop bandwidth is usually higher than open loop</li>
            <li>• Open loop analysis helps design controller parameters</li>
          </ul>
        </div>
      </Card>

      {/* Detailed Comparisons */}
      <Tabs defaultValue="frequency" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="frequency">Frequency Response</TabsTrigger>
          <TabsTrigger value="step">Step Response</TabsTrigger>
          <TabsTrigger value="poles">Pole-Zero Map</TabsTrigger>
        </TabsList>

        <TabsContent value="frequency">
          <div className="space-y-6">
            {/* Magnitude Comparison */}
            <Card className="p-6 shadow-medium border-border/50">
              <h3 className="text-lg font-semibold mb-4">Magnitude Response Comparison</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={combinedFreqResponse}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="frequency" 
                      scale="log" 
                      domain={['dataMin', 'dataMax']}
                      type="number"
                      tick={{ fontSize: 12 }}
                      label={{ value: 'Frequency (rad/s)', position: 'insideBottom', offset: -5 }}
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }}
                      label={{ value: 'Magnitude (dB)', angle: -90, position: 'insideLeft' }}
                    />
                    <Tooltip 
                      formatter={(value, name) => [
                        `${Number(value).toFixed(2)} dB`, 
                        name === 'openMagnitudeDb' ? 'Open Loop' : 'Closed Loop'
                      ]}
                      labelFormatter={(value) => `Frequency: ${Number(value).toFixed(3)} rad/s`}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="openMagnitudeDb" 
                      stroke="hsl(var(--secondary))" 
                      strokeWidth={2}
                      dot={false}
                      name="Open Loop G(s)"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="closedMagnitudeDb" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      dot={false}
                      name="Closed Loop T(s)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>

            {/* Phase Comparison */}
            <Card className="p-6 shadow-medium border-border/50">
              <h3 className="text-lg font-semibold mb-4">Phase Response Comparison</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={combinedFreqResponse}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="frequency" 
                      scale="log" 
                      domain={['dataMin', 'dataMax']}
                      type="number"
                      tick={{ fontSize: 12 }}
                      label={{ value: 'Frequency (rad/s)', position: 'insideBottom', offset: -5 }}
                    />
                    <YAxis 
                      tick={{ fontSize: 12 }}
                      label={{ value: 'Phase (degrees)', angle: -90, position: 'insideLeft' }}
                    />
                    <Tooltip 
                      formatter={(value, name) => [
                        `${Number(value).toFixed(2)}°`, 
                        name === 'openPhase' ? 'Open Loop' : 'Closed Loop'
                      ]}
                      labelFormatter={(value) => `Frequency: ${Number(value).toFixed(3)} rad/s`}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="openPhase" 
                      stroke="hsl(var(--secondary))" 
                      strokeWidth={2}
                      dot={false}
                      name="Open Loop G(s)"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="closedPhase" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      dot={false}
                      name="Closed Loop T(s)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="step">
          <Card className="p-6 shadow-medium border-border/50">
            <h3 className="text-lg font-semibold mb-4">Step Response Comparison</h3>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={combinedStepResponse}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="time" 
                    tick={{ fontSize: 12 }}
                    label={{ value: 'Time (s)', position: 'insideBottom', offset: -5 }}
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    label={{ value: 'Amplitude', angle: -90, position: 'insideLeft' }}
                  />
                  <Tooltip 
                    formatter={(value, name) => [
                      Number(value).toFixed(4), 
                      name === 'openStep' ? 'Open Loop' : 'Closed Loop'
                    ]}
                    labelFormatter={(value) => `Time: ${Number(value).toFixed(3)} s`}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="openStep" 
                    stroke="hsl(var(--secondary))" 
                    strokeWidth={2}
                    dot={false}
                    name="Open Loop G(s)"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="closedStep" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={false}
                    name="Closed Loop T(s)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid md:grid-cols-2 gap-4">
              <div className="bg-muted/20 p-3 rounded">
                <h4 className="text-sm font-medium mb-2">Closed Loop Performance:</h4>
                <div className="text-sm space-y-1">
                  <div>Rise Time: {isFinite(closedLoop.riseTime) ? `${closedLoop.riseTime.toFixed(3)} s` : 'N/A'}</div>
                  <div>Settling Time: {isFinite(closedLoop.settlingTime) ? `${closedLoop.settlingTime.toFixed(3)} s` : 'N/A'}</div>
                </div>
              </div>
              <div className="bg-muted/20 p-3 rounded">
                <h4 className="text-sm font-medium mb-2">Key Differences:</h4>
                <div className="text-sm text-muted-foreground">
                  Closed loop typically shows faster response and better regulation
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="poles">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Open Loop Poles */}
            <Card className="p-6 shadow-medium border-border/50">
              <h3 className="text-lg font-semibold mb-4">Open Loop Poles & Zeros</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Poles</h4>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {openLoop.poles.length > 0 ? (
                      openLoop.poles.map((pole, index) => (
                        <div key={index} className="text-sm font-mono bg-muted/30 p-2 rounded">
                          {formatComplex(pole)}
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No poles found</p>
                    )}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Zeros</h4>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {openLoop.zeros.length > 0 ? (
                      openLoop.zeros.map((zero, index) => (
                        <div key={index} className="text-sm font-mono bg-muted/30 p-2 rounded">
                          {formatComplex(zero)}
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No zeros found</p>
                    )}
                  </div>
                </div>
              </div>
            </Card>

            {/* Closed Loop Poles */}
            <Card className="p-6 shadow-medium border-border/50">
              <h3 className="text-lg font-semibold mb-4">Closed Loop Poles & Zeros</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Poles</h4>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {closedLoop.poles.length > 0 ? (
                      closedLoop.poles.map((pole, index) => (
                        <div key={index} className="text-sm font-mono bg-muted/30 p-2 rounded">
                          {formatComplex(pole)}
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No poles found</p>
                    )}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Zeros</h4>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {closedLoop.zeros.length > 0 ? (
                      closedLoop.zeros.map((zero, index) => (
                        <div key={index} className="text-sm font-mono bg-muted/30 p-2 rounded">
                          {formatComplex(zero)}
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No zeros found</p>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LoopAnalysis;