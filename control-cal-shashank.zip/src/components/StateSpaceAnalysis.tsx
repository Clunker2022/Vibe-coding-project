import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Settings } from 'lucide-react';

interface StateSpaceAnalysisProps {
  A: number[][];
  B: number[][];
  C: number[][];
  D: number[][];
  isControllable: boolean;
  isObservable: boolean;
  eigenvalues: { real: number; imaginary: number; }[];
}

const formatMatrix = (matrix: number[][], name: string): JSX.Element => (
  <div className="space-y-2">
    <h4 className="text-sm font-medium">{name} Matrix:</h4>
    <div className="bg-muted/30 p-3 rounded font-mono text-sm">
      <div className="flex flex-col">
        {matrix.map((row, i) => (
          <div key={i} className="flex gap-2">
            <span>[</span>
            {row.map((val, j) => (
              <span key={j} className="min-w-[60px] text-center">
                {val.toFixed(3)}
              </span>
            ))}
            <span>]</span>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const formatComplex = (complex: { real: number; imaginary: number; }): string => {
  if (Math.abs(complex.imaginary) < 1e-10) {
    return complex.real.toFixed(4);
  }
  const sign = complex.imaginary >= 0 ? '+' : '-';
  return `${complex.real.toFixed(4)} ${sign} ${Math.abs(complex.imaginary).toFixed(4)}j`;
};

const StateSpaceAnalysis: React.FC<StateSpaceAnalysisProps> = ({
  A,
  B,
  C,
  D,
  isControllable,
  isObservable,
  eigenvalues
}) => {
  return (
    <Card className="p-6 shadow-medium border-border/50">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Settings className="h-5 w-5 text-primary" />
        State Space Analysis
      </h2>
      
      <div className="space-y-6">
        {/* State Space Representation */}
        <div>
          <h3 className="font-medium mb-3">State Space Representation</h3>
          <div className="bg-muted/20 p-4 rounded-lg">
            <div className="font-mono text-sm mb-2">
              ẋ(t) = Ax(t) + Bu(t)
            </div>
            <div className="font-mono text-sm">
              y(t) = Cx(t) + Du(t)
            </div>
          </div>
        </div>

        {/* Matrices */}
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-4">
            {formatMatrix(A, 'A')}
            {formatMatrix(B, 'B')}
          </div>
          <div className="space-y-4">
            {formatMatrix(C, 'C')}
            {formatMatrix(D, 'D')}
          </div>
        </div>

        <Separator />

        {/* System Properties */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="font-medium">System Properties</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Controllability:</span>
                <Badge 
                  variant={isControllable ? "default" : "destructive"}
                  className={isControllable ? "bg-secondary" : ""}
                >
                  {isControllable ? 'Controllable' : 'Not Controllable'}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Observability:</span>
                <Badge 
                  variant={isObservable ? "default" : "destructive"}
                  className={isObservable ? "bg-secondary" : ""}
                >
                  {isObservable ? 'Observable' : 'Not Observable'}
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium">Eigenvalues (System Poles)</h3>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {eigenvalues.length > 0 ? (
                eigenvalues.map((eigenvalue, index) => (
                  <div key={index} className="text-sm font-mono bg-muted/30 p-2 rounded">
                    {formatComplex(eigenvalue)}
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No eigenvalues found</p>
              )}
            </div>
          </div>
        </div>

        {/* Additional Information */}
        <div className="bg-muted/20 p-4 rounded-lg">
          <h4 className="text-sm font-medium mb-2">State Space Notes:</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• The state space representation provides a complete description of the system dynamics</li>
            <li>• Controllability determines if all states can be controlled through the input</li>
            <li>• Observability determines if all states can be determined from the output</li>
            <li>• Eigenvalues of the A matrix are the system poles and determine stability</li>
          </ul>
        </div>
      </div>
    </Card>
  );
};

export default StateSpaceAnalysis;