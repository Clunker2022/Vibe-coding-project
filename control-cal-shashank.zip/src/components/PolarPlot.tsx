import React from 'react';
import { Card } from '@/components/ui/card';
import { ResponsiveContainer, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, RadarChart, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

interface PolarPlotProps {
  frequencyResponse: Array<{
    frequency: number;
    magnitude: number;
    magnitudeDb: number;
    phase: number;
  }>;
  timeResponse: {
    step: Array<{ time: number; amplitude: number; }>;
    impulse: Array<{ time: number; amplitude: number; }>;
  };
}

const PolarPlot: React.FC<PolarPlotProps> = ({ frequencyResponse, timeResponse }) => {
  // Convert frequency response to polar coordinates
  const polarData = frequencyResponse.map((point, index) => ({
    angle: point.phase,
    magnitude: point.magnitude,
    frequency: point.frequency,
    index
  }));

  // Create polar plot data in format suitable for radar chart
  const radarData = frequencyResponse.slice(0, 36).map((point, index) => ({
    subject: `${(index * 10)}°`,
    magnitude: point.magnitude,
    phase: point.phase,
    frequency: point.frequency
  }));

  return (
    <div className="space-y-6">
      {/* Polar Plot */}
      <Card className="p-6 shadow-medium border-border/50">
        <h3 className="text-lg font-semibold mb-4">Polar Plot</h3>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData}>
              <PolarGrid stroke="hsl(var(--border))" />
              <PolarAngleAxis 
                dataKey="subject" 
                tick={{ fontSize: 10 }}
                className="text-muted-foreground"
              />
              <PolarRadiusAxis 
                angle={90} 
                domain={[0, 'dataMax']}
                tick={{ fontSize: 10 }}
                className="text-muted-foreground"
              />
              <Radar
                name="Magnitude"
                dataKey="magnitude"
                stroke="hsl(var(--primary))"
                fill="hsl(var(--primary))"
                fillOpacity={0.1}
                strokeWidth={2}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          Polar plot shows magnitude vs phase angle. Each point represents the frequency response at different frequencies.
        </p>
      </Card>

      {/* Time Domain Responses */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Step Response */}
        <Card className="p-6 shadow-medium border-border/50">
          <h3 className="text-lg font-semibold mb-4">Step Response</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeResponse.step}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 12 }}
                  label={{ value: 'Time (s)', position: 'insideBottom', offset: -5 }}
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  label={{ value: 'Amplitude', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  formatter={(value, name) => [Number(value).toFixed(4), 'Amplitude']}
                  labelFormatter={(value) => `Time: ${Number(value).toFixed(3)} s`}
                />
                <Line 
                  type="monotone" 
                  dataKey="amplitude" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Impulse Response */}
        <Card className="p-6 shadow-medium border-border/50">
          <h3 className="text-lg font-semibold mb-4">Impulse Response</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeResponse.impulse}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 12 }}
                  label={{ value: 'Time (s)', position: 'insideBottom', offset: -5 }}
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  label={{ value: 'Amplitude', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  formatter={(value, name) => [Number(value).toFixed(4), 'Amplitude']}
                  labelFormatter={(value) => `Time: ${Number(value).toFixed(3)} s`}
                />
                <Line 
                  type="monotone" 
                  dataKey="amplitude" 
                  stroke="hsl(var(--secondary))" 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default PolarPlot;