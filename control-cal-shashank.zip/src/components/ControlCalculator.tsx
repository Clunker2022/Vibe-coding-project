import React, { useState, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calculator, Activity, TrendingUp, BarChart3, Zap, Settings, Target, PieChart, GitBranch } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ScatterChart, Scatter, ReferenceLine } from 'recharts';
import SystemAnalysis from './SystemAnalysis';
import StateSpaceAnalysis from './StateSpaceAnalysis';
import PolarPlot from './PolarPlot';
import AdvancedAnalysis from './AdvancedAnalysis';
import LoopAnalysis from './LoopAnalysis';
import { 
  parseCoefficients, 
  findRoots, 
  calculateDCGain, 
  isSystemStable,
  getSystemType,
  getSystemOrder,
  calculateSteadyStateErrors,
  transferFunctionToStateSpace,
  checkControllability,
  checkObservability,
  calculateEigenvalues,
  calculateStabilityMargins,
  calculateBandwidth,
  calculateResonantCharacteristics,
  calculateSecondOrderParams,
  calculateTimeCharacteristics,
  isMinimumPhase,
  calculateTimeResponses,
  analyzeClosedLoopSystem
} from '@/utils/controlSystemUtils';

interface Polynomial {
  coefficients: number[];
}

interface TransferFunction {
  numerator: Polynomial;
  denominator: Polynomial;
}

interface AnalysisResult {
  poles: Complex[];
  zeros: Complex[];
  dcGain: number;
  isStable: boolean;
  systemType: number;
  systemOrder: number;
  steadyStateErrors: {
    step: number;
    ramp: number;
    parabolic: number;
  };
  stateSpace: {
    A: number[][];
    B: number[][];
    C: number[][];
    D: number[][];
    isControllable: boolean;
    isObservable: boolean;
    eigenvalues: Complex[];
  };
  advanced: {
    gainMargin: number;
    phaseMargin: number;
    bandwidth: number;
    peakOvershoot: number;
    settlingTime: number;
    riseTime: number;
    naturalFrequency: number;
    dampingRatio: number;
    resonantFrequency: number;
    resonantPeak: number;
    isMinimumPhase: boolean;
  };
  timeResponse: {
    step: Array<{ time: number; amplitude: number; }>;
    impulse: Array<{ time: number; amplitude: number; }>;
  };
  closedLoop: {
    poles: Complex[];
    zeros: Complex[];
    dcGain: number;
    isStable: boolean;
    frequencyResponse: FrequencyPoint[];
    timeResponse: {
      step: Array<{ time: number; amplitude: number; }>;
      impulse: Array<{ time: number; amplitude: number; }>;
    };
    bandwidth: number;
    peakOvershoot: number;
    settlingTime: number;
    riseTime: number;
  };
  frequencyResponse: FrequencyPoint[];
  nyquistData: NyquistPoint[];
}

interface FrequencyPoint {
  frequency: number;
  magnitude: number;
  magnitudeDb: number;
  phase: number;
}

interface NyquistPoint {
  real: number;
  imaginary: number;
  frequency: number;
}

interface Complex {
  real: number;
  imaginary: number;
}

const ControlCalculator = () => {
  const [numCoeffs, setNumCoeffs] = useState<string>('1');
  const [denCoeffs, setDenCoeffs] = useState<string>('1 1');
  const [result, setResult] = useState<AnalysisResult | null>(null);

  // Evaluate polynomial at complex number s = jω
  const evaluatePolynomial = (coefficients: number[], s: Complex): Complex => {
    let result = { real: 0, imaginary: 0 };
    
    for (let i = 0; i < coefficients.length; i++) {
      const power = coefficients.length - 1 - i;
      const term = complexPower(s, power);
      const scaledTerm = complexMultiply(term, { real: coefficients[i], imaginary: 0 });
      result = complexAdd(result, scaledTerm);
    }
    
    return result;
  };

  // Complex number operations
  const complexAdd = (a: Complex, b: Complex): Complex => ({
    real: a.real + b.real,
    imaginary: a.imaginary + b.imaginary
  });

  const complexMultiply = (a: Complex, b: Complex): Complex => ({
    real: a.real * b.real - a.imaginary * b.imaginary,
    imaginary: a.real * b.imaginary + a.imaginary * b.real
  });

  const complexDivide = (a: Complex, b: Complex): Complex => {
    const denominator = b.real * b.real + b.imaginary * b.imaginary;
    return {
      real: (a.real * b.real + a.imaginary * b.imaginary) / denominator,
      imaginary: (a.imaginary * b.real - a.real * b.imaginary) / denominator
    };
  };

  const complexPower = (base: Complex, power: number): Complex => {
    if (power === 0) return { real: 1, imaginary: 0 };
    if (power === 1) return base;
    
    let result = { real: 1, imaginary: 0 };
    for (let i = 0; i < power; i++) {
      result = complexMultiply(result, base);
    }
    return result;
  };

  const complexMagnitude = (c: Complex): number => 
    Math.sqrt(c.real * c.real + c.imaginary * c.imaginary);

  const complexPhase = (c: Complex): number => 
    Math.atan2(c.imaginary, c.real);

  // Calculate frequency response
  const calculateFrequencyResponse = (numCoeffs: number[], denCoeffs: number[]): { frequencyResponse: FrequencyPoint[], nyquistData: NyquistPoint[] } => {
    const frequencyResponse: FrequencyPoint[] = [];
    const nyquistData: NyquistPoint[] = [];
    
    // Generate frequency range (logarithmic)
    const startFreq = 0.01;
    const endFreq = 100;
    const numPoints = 200;
    
    for (let i = 0; i < numPoints; i++) {
      const frequency = startFreq * Math.pow(endFreq / startFreq, i / (numPoints - 1));
      const s = { real: 0, imaginary: frequency }; // s = jω
      
      const numerator = evaluatePolynomial(numCoeffs, s);
      const denominator = evaluatePolynomial(denCoeffs, s);
      const response = complexDivide(numerator, denominator);
      
      const magnitude = complexMagnitude(response);
      const magnitudeDb = 20 * Math.log10(magnitude);
      const phase = complexPhase(response) * 180 / Math.PI; // Convert to degrees
      
      frequencyResponse.push({
        frequency,
        magnitude,
        magnitudeDb: isFinite(magnitudeDb) ? magnitudeDb : -100,
        phase: isFinite(phase) ? phase : 0
      });
      
      nyquistData.push({
        real: response.real,
        imaginary: response.imaginary,
        frequency
      });
    }
    
    return { frequencyResponse, nyquistData };
  };

  const analyzeTransferFunction = useCallback(() => {
    const numCoefficients = parseCoefficients(numCoeffs);
    const denCoefficients = parseCoefficients(denCoeffs);
    
    if (numCoefficients.length === 0 || denCoefficients.length === 0) {
      return;
    }

    const zeros = findRoots(numCoefficients);
    const poles = findRoots(denCoefficients);
    const dcGain = calculateDCGain(numCoefficients, denCoefficients);
    const isStable = isSystemStable(poles);
    const systemType = getSystemType(denCoefficients);
    const systemOrder = getSystemOrder(denCoefficients);
    const steadyStateErrors = calculateSteadyStateErrors(numCoefficients, denCoefficients, systemType);
    const { frequencyResponse, nyquistData } = calculateFrequencyResponse(numCoefficients, denCoefficients);
    
    // State space analysis
    const stateSpaceRepr = transferFunctionToStateSpace(numCoefficients, denCoefficients);
    const isControllable = checkControllability(stateSpaceRepr.A, stateSpaceRepr.B);
    const isObservable = checkObservability(stateSpaceRepr.A, stateSpaceRepr.C);
    const eigenvalues = calculateEigenvalues(stateSpaceRepr.A);

    // Advanced analysis
    const { gainMargin, phaseMargin } = calculateStabilityMargins(frequencyResponse);
    const bandwidth = calculateBandwidth(frequencyResponse);
    const { resonantFrequency, resonantPeak } = calculateResonantCharacteristics(frequencyResponse);
    const { naturalFrequency, dampingRatio } = calculateSecondOrderParams(poles);
    const { peakOvershoot, settlingTime, riseTime } = calculateTimeCharacteristics(dampingRatio, naturalFrequency);
    const minimumPhase = isMinimumPhase(zeros);
    const timeResponse = calculateTimeResponses(numCoefficients, denCoefficients);

    // Closed loop analysis
    const closedLoopAnalysis = analyzeClosedLoopSystem(numCoefficients, denCoefficients);

    setResult({
      poles,
      zeros,
      dcGain,
      isStable,
      systemType,
      systemOrder,
      steadyStateErrors,
      stateSpace: {
        ...stateSpaceRepr,
        isControllable,
        isObservable,
        eigenvalues
      },
      advanced: {
        gainMargin,
        phaseMargin,
        bandwidth,
        peakOvershoot,
        settlingTime,
        riseTime,
        naturalFrequency,
        dampingRatio,
        resonantFrequency,
        resonantPeak,
        isMinimumPhase: minimumPhase
      },
      timeResponse,
      closedLoop: closedLoopAnalysis,
      frequencyResponse,
      nyquistData
    });
  }, [numCoeffs, denCoeffs]);

  const formatComplex = (complex: Complex): string => {
    if (Math.abs(complex.imaginary) < 1e-10) {
      return complex.real.toFixed(4);
    }
    const sign = complex.imaginary >= 0 ? '+' : '-';
    return `${complex.real.toFixed(4)} ${sign} ${Math.abs(complex.imaginary).toFixed(4)}j`;
  };

  const formatPolynomial = (coeffs: string): string => {
    const coefficients = parseCoefficients(coeffs);
    if (coefficients.length === 0) return '';
    
    return coefficients
      .map((coeff, index) => {
        const power = coefficients.length - 1 - index;
        if (power === 0) return coeff.toString();
        if (power === 1) return `${coeff}s`;
        return `${coeff}s^${power}`;
      })
      .join(' + ')
      .replace(/\+ -/g, '- ');
  };

  return (
    <div className="min-h-screen bg-gradient-surface p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 bg-gradient-primary rounded-xl shadow-medium">
              <Calculator className="h-8 w-8 text-primary-foreground" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Control System Calculator
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Analyze transfer functions with poles, zeros, stability, and frequency response plots
          </p>
        </div>

        {/* Input Section */}
        <Card className="p-6 shadow-medium border-border/50">
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold">Transfer Function Input</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="numerator" className="text-sm font-medium">
                  Numerator Coefficients
                </Label>
                <Input
                  id="numerator"
                  placeholder="e.g., 1 2 1 (for s² + 2s + 1)"
                  value={numCoeffs}
                  onChange={(e) => setNumCoeffs(e.target.value)}
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground">
                  Space-separated coefficients from highest to lowest degree
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="denominator" className="text-sm font-medium">
                  Denominator Coefficients
                </Label>
                <Input
                  id="denominator"
                  placeholder="e.g., 1 3 2 (for s² + 3s + 2)"
                  value={denCoeffs}
                  onChange={(e) => setDenCoeffs(e.target.value)}
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground">
                  Space-separated coefficients from highest to lowest degree
                </p>
              </div>
            </div>

            {/* Transfer Function Display */}
            {(numCoeffs.trim() || denCoeffs.trim()) && (
              <div className="bg-muted/30 p-4 rounded-lg border">
                <h3 className="text-sm font-medium mb-2">Transfer Function G(s):</h3>
                <div className="font-mono text-center space-y-1">
                  <div className="text-lg">
                    {formatPolynomial(numCoeffs) || '1'}
                  </div>
                  <div className="border-t border-foreground/20 mx-8"></div>
                  <div className="text-lg">
                    {formatPolynomial(denCoeffs) || '1'}
                  </div>
                </div>
              </div>
            )}

            <Button 
              onClick={analyzeTransferFunction}
              className="w-full bg-gradient-primary hover:opacity-90 transition-opacity"
              size="lg"
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Analyze System
            </Button>
          </div>
        </Card>

        {/* Results Section */}
        {result && (
          <Tabs defaultValue="analysis" className="space-y-6">
            <TabsList className="grid w-full grid-cols-7">
              <TabsTrigger value="analysis" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Analysis
              </TabsTrigger>
              <TabsTrigger value="loop" className="flex items-center gap-2">
                <GitBranch className="h-4 w-4" />
                Loop Analysis
              </TabsTrigger>
              <TabsTrigger value="advanced" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Advanced
              </TabsTrigger>
              <TabsTrigger value="statespace" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                State Space
              </TabsTrigger>
              <TabsTrigger value="polar" className="flex items-center gap-2">
                <PieChart className="h-4 w-4" />
                Polar/Time
              </TabsTrigger>
              <TabsTrigger value="bode" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Bode Plot
              </TabsTrigger>
              <TabsTrigger value="nyquist" className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Nyquist Plot
              </TabsTrigger>
            </TabsList>

            <TabsContent value="analysis">
              <SystemAnalysis
                poles={result.poles}
                zeros={result.zeros}
                dcGain={result.dcGain}
                isStable={result.isStable}
                systemType={result.systemType}
                systemOrder={result.systemOrder}
                steadyStateErrors={result.steadyStateErrors}
              />
            </TabsContent>

            <TabsContent value="loop">
              <LoopAnalysis
                openLoop={{
                  poles: result.poles,
                  zeros: result.zeros,
                  dcGain: result.dcGain,
                  isStable: result.isStable,
                  frequencyResponse: result.frequencyResponse,
                  timeResponse: result.timeResponse
                }}
                closedLoop={result.closedLoop}
              />
            </TabsContent>

            <TabsContent value="advanced">
              <AdvancedAnalysis
                gainMargin={result.advanced.gainMargin}
                phaseMargin={result.advanced.phaseMargin}
                bandwidth={result.advanced.bandwidth}
                peakOvershoot={result.advanced.peakOvershoot}
                settlingTime={result.advanced.settlingTime}
                riseTime={result.advanced.riseTime}
                naturalFrequency={result.advanced.naturalFrequency}
                dampingRatio={result.advanced.dampingRatio}
                resonantFrequency={result.advanced.resonantFrequency}
                resonantPeak={result.advanced.resonantPeak}
                isMinimumPhase={result.advanced.isMinimumPhase}
              />
            </TabsContent>

            <TabsContent value="statespace">
              <StateSpaceAnalysis
                A={result.stateSpace.A}
                B={result.stateSpace.B}
                C={result.stateSpace.C}
                D={result.stateSpace.D}
                isControllable={result.stateSpace.isControllable}
                isObservable={result.stateSpace.isObservable}
                eigenvalues={result.stateSpace.eigenvalues}
              />
            </TabsContent>

            <TabsContent value="polar">
              <PolarPlot
                frequencyResponse={result.frequencyResponse}
                timeResponse={result.timeResponse}
              />
            </TabsContent>

            <TabsContent value="bode">
              <div className="space-y-6">
                {/* Magnitude Plot */}
                <Card className="p-6 shadow-medium border-border/50">
                  <h3 className="text-lg font-semibold mb-4">Bode Magnitude Plot</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={result.frequencyResponse}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis 
                          dataKey="frequency" 
                          scale="log" 
                          domain={['dataMin', 'dataMax']}
                          type="number"
                          tick={{ fontSize: 12 }}
                          label={{ value: 'Frequency (rad/s)', position: 'insideBottom', offset: -5 }}
                        />
                        <YAxis 
                          tick={{ fontSize: 12 }}
                          label={{ value: 'Magnitude (dB)', angle: -90, position: 'insideLeft' }}
                        />
                        <Tooltip 
                          formatter={(value, name) => [
                            `${Number(value).toFixed(2)} dB`, 
                            'Magnitude'
                          ]}
                          labelFormatter={(value) => `Frequency: ${Number(value).toFixed(3)} rad/s`}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="magnitudeDb" 
                          stroke="hsl(var(--primary))" 
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                {/* Phase Plot */}
                <Card className="p-6 shadow-medium border-border/50">
                  <h3 className="text-lg font-semibold mb-4">Bode Phase Plot</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={result.frequencyResponse}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis 
                          dataKey="frequency" 
                          scale="log" 
                          domain={['dataMin', 'dataMax']}
                          type="number"
                          tick={{ fontSize: 12 }}
                          label={{ value: 'Frequency (rad/s)', position: 'insideBottom', offset: -5 }}
                        />
                        <YAxis 
                          tick={{ fontSize: 12 }}
                          label={{ value: 'Phase (degrees)', angle: -90, position: 'insideLeft' }}
                        />
                        <Tooltip 
                          formatter={(value, name) => [
                            `${Number(value).toFixed(2)}°`, 
                            'Phase'
                          ]}
                          labelFormatter={(value) => `Frequency: ${Number(value).toFixed(3)} rad/s`}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="phase" 
                          stroke="hsl(var(--secondary))" 
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="nyquist">
              <Card className="p-6 shadow-medium border-border/50">
                <h3 className="text-lg font-semibold mb-4">Nyquist Plot</h3>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart data={result.nyquistData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="real" 
                        type="number"
                        tick={{ fontSize: 12 }}
                        label={{ value: 'Real Part', position: 'insideBottom', offset: -5 }}
                      />
                      <YAxis 
                        dataKey="imaginary" 
                        type="number"
                        tick={{ fontSize: 12 }}
                        label={{ value: 'Imaginary Part', angle: -90, position: 'insideLeft' }}
                      />
                      <ReferenceLine x={0} stroke="hsl(var(--muted-foreground))" strokeDasharray="2 2" />
                      <ReferenceLine y={0} stroke="hsl(var(--muted-foreground))" strokeDasharray="2 2" />
                      <Tooltip 
                        formatter={(value, name) => [
                          Number(value).toFixed(4), 
                          name === 'real' ? 'Real' : 'Imaginary'
                        ]}
                        labelFormatter={(_, payload) => 
                          payload?.[0]?.payload?.frequency ? 
                          `Frequency: ${payload[0].payload.frequency.toFixed(3)} rad/s` : ''
                        }
                      />
                      <Scatter 
                        dataKey="imaginary" 
                        fill="hsl(var(--accent))"
                        line={{ stroke: 'hsl(var(--accent))', strokeWidth: 2 }}
                      />
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  The Nyquist plot shows the complex frequency response. Each point represents G(jω) for a specific frequency ω.
                </p>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
};

export default ControlCalculator;