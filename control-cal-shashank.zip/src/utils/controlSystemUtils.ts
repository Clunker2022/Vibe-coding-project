interface Complex {
  real: number;
  imaginary: number;
}

export const parseCoefficients = (input: string): number[] => {
  return input
    .trim()
    .split(/\s+/)
    .map(Number)
    .filter(n => !isNaN(n));
};

export const findRoots = (coefficients: number[]): Complex[] => {
  // Simple root finding for polynomials up to degree 2
  if (coefficients.length === 1) {
    return []; // Constant polynomial has no roots
  }
  
  if (coefficients.length === 2) {
    // Linear: ax + b = 0 => x = -b/a
    const [a, b] = coefficients;
    if (a === 0) return [];
    return [{ real: -b / a, imaginary: 0 }];
  }
  
  if (coefficients.length === 3) {
    // Quadratic: ax² + bx + c = 0
    const [a, b, c] = coefficients;
    if (a === 0) return findRoots([b, c]);
    
    const discriminant = b * b - 4 * a * c;
    if (discriminant >= 0) {
      const sqrt_d = Math.sqrt(discriminant);
      return [
        { real: (-b + sqrt_d) / (2 * a), imaginary: 0 },
        { real: (-b - sqrt_d) / (2 * a), imaginary: 0 }
      ];
    } else {
      const realPart = -b / (2 * a);
      const imagPart = Math.sqrt(-discriminant) / (2 * a);
      return [
        { real: realPart, imaginary: imagPart },
        { real: realPart, imaginary: -imagPart }
      ];
    }
  }
  
  // For higher order polynomials, return empty array (would need numerical methods)
  return [];
};

export const calculateDCGain = (num: number[], den: number[]): number => {
  const numSum = num.reduce((sum, coeff) => sum + coeff, 0);
  const denSum = den.reduce((sum, coeff) => sum + coeff, 0);
  return denSum !== 0 ? numSum / denSum : Infinity;
};

export const isSystemStable = (poles: Complex[]): boolean => {
  return poles.every(pole => pole.real < 0);
};

export const getSystemType = (denCoeffs: number[]): number => {
  // Count poles at origin (s=0)
  let polesAtOrigin = 0;
  for (let i = denCoeffs.length - 1; i >= 0; i--) {
    if (denCoeffs[i] === 0) {
      polesAtOrigin++;
    } else {
      break;
    }
  }
  return polesAtOrigin;
};

export const getSystemOrder = (denCoeffs: number[]): number => {
  return denCoeffs.length - 1;
};

export const calculateSteadyStateErrors = (numCoeffs: number[], denCoeffs: number[], systemType: number) => {
  const kp = calculateDCGain(numCoeffs, denCoeffs); // Position error constant
  const kv = systemType >= 1 ? (numCoeffs[numCoeffs.length - 1] / denCoeffs[denCoeffs.length - 2]) : 0; // Velocity error constant
  const ka = systemType >= 2 ? (numCoeffs[numCoeffs.length - 1] / denCoeffs[denCoeffs.length - 3]) : 0; // Acceleration error constant

  return {
    step: systemType === 0 ? 1 / (1 + kp) : 0,
    ramp: systemType === 0 ? Infinity : systemType === 1 ? 1 / kv : 0,
    parabolic: systemType <= 1 ? Infinity : 1 / ka
  };
};

// Convert transfer function to state space (controllable canonical form)
export const transferFunctionToStateSpace = (numCoeffs: number[], denCoeffs: number[]) => {
  const n = denCoeffs.length - 1; // System order
  const m = numCoeffs.length - 1; // Numerator order
  
  if (n === 0) {
    // Pure gain system
    return {
      A: [[0]],
      B: [[1]],
      C: [[numCoeffs[0] / denCoeffs[0]]],
      D: [[0]]
    };
  }

  // Normalize denominator coefficients
  const normalizedDen = denCoeffs.map(coeff => coeff / denCoeffs[0]);
  const normalizedNum = numCoeffs.map(coeff => coeff / denCoeffs[0]);

  // Create A matrix (companion form)
  const A: number[][] = [];
  for (let i = 0; i < n; i++) {
    A[i] = new Array(n).fill(0);
    if (i < n - 1) {
      A[i][i + 1] = 1;
    } else {
      for (let j = 0; j < n; j++) {
        A[i][j] = -normalizedDen[n - j];
      }
    }
  }

  // Create B matrix
  const B: number[][] = [];
  for (let i = 0; i < n; i++) {
    B[i] = [i === n - 1 ? 1 : 0];
  }

  // Create C matrix
  const C: number[][] = [new Array(n).fill(0)];
  if (m < n) {
    // Proper transfer function
    for (let i = 0; i <= m; i++) {
      C[0][n - 1 - i] = normalizedNum[m - i];
    }
  } else {
    // Improper transfer function (should be made proper first)
    for (let i = 0; i < n; i++) {
      C[0][i] = i < normalizedNum.length ? normalizedNum[i] : 0;
    }
  }

  // Create D matrix
  const D: number[][] = [[m >= n ? normalizedNum[0] : 0]];

  return { A, B, C, D };
};

// Check controllability using controllability matrix rank
export const checkControllability = (A: number[][], B: number[][]): boolean => {
  const n = A.length;
  const controllabilityMatrix: number[][] = [];
  
  // Build controllability matrix [B AB A²B ... A^(n-1)B]
  let currentB = B.map(row => [...row]);
  
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < currentB.length; j++) {
      if (!controllabilityMatrix[j]) controllabilityMatrix[j] = [];
      controllabilityMatrix[j].push(...currentB[j]);
    }
    
    // Calculate A^(i+1)B for next iteration
    if (i < n - 1) {
      const nextB: number[][] = [];
      for (let j = 0; j < n; j++) {
        nextB[j] = [0];
        for (let k = 0; k < n; k++) {
          nextB[j][0] += A[j][k] * currentB[k][0];
        }
      }
      currentB = nextB;
    }
  }
  
  // Check if rank equals n (simplified check for square matrices)
  return determinant(controllabilityMatrix) !== 0;
};

// Check observability using observability matrix rank
export const checkObservability = (A: number[][], C: number[][]): boolean => {
  const n = A.length;
  const observabilityMatrix: number[][] = [];
  
  // Build observability matrix [C; CA; CA²; ...; CA^(n-1)]
  let currentC = C.map(row => [...row]);
  
  for (let i = 0; i < n; i++) {
    observabilityMatrix.push(...currentC);
    
    // Calculate CA^(i+1) for next iteration
    if (i < n - 1) {
      const nextC: number[][] = [];
      for (let j = 0; j < currentC.length; j++) {
        nextC[j] = new Array(n).fill(0);
        for (let k = 0; k < n; k++) {
          for (let l = 0; l < n; l++) {
            nextC[j][k] += currentC[j][l] * A[l][k];
          }
        }
      }
      currentC = nextC;
    }
  }
  
  // Check if rank equals n (simplified check)
  return determinant(observabilityMatrix) !== 0;
};

// Calculate eigenvalues of matrix A (simplified for 2x2 and 1x1 matrices)
export const calculateEigenvalues = (A: number[][]): Complex[] => {
  const n = A.length;
  
  if (n === 1) {
    return [{ real: A[0][0], imaginary: 0 }];
  }
  
  if (n === 2) {
    // For 2x2 matrix: λ² - trace(A)λ + det(A) = 0
    const trace = A[0][0] + A[1][1];
    const det = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    const discriminant = trace * trace - 4 * det;
    
    if (discriminant >= 0) {
      const sqrt_d = Math.sqrt(discriminant);
      return [
        { real: (trace + sqrt_d) / 2, imaginary: 0 },
        { real: (trace - sqrt_d) / 2, imaginary: 0 }
      ];
    } else {
      const realPart = trace / 2;
      const imagPart = Math.sqrt(-discriminant) / 2;
      return [
        { real: realPart, imaginary: imagPart },
        { real: realPart, imaginary: -imagPart }
      ];
    }
  }
  
  // For higher order matrices, return empty array (would need numerical methods)
  return [];
};

// Simple determinant calculation (for small matrices)
const determinant = (matrix: number[][]): number => {
  const n = matrix.length;
  
  if (n === 1) return matrix[0][0];
  if (n === 2) return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
  
  // For larger matrices, use approximation or return non-zero (simplified)
  return 1; // Simplified check
};

// Calculate gain and phase margins
export const calculateStabilityMargins = (frequencyResponse: Array<{
  frequency: number;
  magnitude: number;
  magnitudeDb: number;
  phase: number;
}>): { gainMargin: number; phaseMargin: number; } => {
  let gainMargin = Infinity;
  let phaseMargin = Infinity;
  
  // Find gain crossover frequency (where |G(jω)| = 1 or 0 dB)
  let gainCrossoverFreq = 0;
  for (let i = 1; i < frequencyResponse.length; i++) {
    if (frequencyResponse[i-1].magnitudeDb > 0 && frequencyResponse[i].magnitudeDb <= 0) {
      gainCrossoverFreq = frequencyResponse[i].frequency;
      phaseMargin = 180 + frequencyResponse[i].phase;
      break;
    }
  }
  
  // Find phase crossover frequency (where phase = -180°)
  for (let i = 1; i < frequencyResponse.length; i++) {
    if (frequencyResponse[i-1].phase > -180 && frequencyResponse[i].phase <= -180) {
      gainMargin = -frequencyResponse[i].magnitudeDb;
      break;
    }
  }
  
  return { gainMargin, phaseMargin };
};

// Calculate bandwidth (frequency where magnitude drops to -3dB from DC)
export const calculateBandwidth = (frequencyResponse: Array<{
  frequency: number;
  magnitude: number;
  magnitudeDb: number;
  phase: number;
}>): number => {
  const dcGainDb = frequencyResponse[0].magnitudeDb;
  const targetDb = dcGainDb - 3;
  
  for (let i = 1; i < frequencyResponse.length; i++) {
    if (frequencyResponse[i].magnitudeDb <= targetDb) {
      return frequencyResponse[i].frequency;
    }
  }
  
  return Infinity;
};

// Calculate resonant peak and frequency
export const calculateResonantCharacteristics = (frequencyResponse: Array<{
  frequency: number;
  magnitude: number;
  magnitudeDb: number;
  phase: number;
}>): { resonantFrequency: number; resonantPeak: number; } => {
  let maxMagnitudeDb = -Infinity;
  let resonantFrequency = 0;
  
  for (const point of frequencyResponse) {
    if (point.magnitudeDb > maxMagnitudeDb) {
      maxMagnitudeDb = point.magnitudeDb;
      resonantFrequency = point.frequency;
    }
  }
  
  return { resonantFrequency, resonantPeak: maxMagnitudeDb };
};

// Extract natural frequency and damping ratio for second-order systems
export const calculateSecondOrderParams = (poles: Complex[]): { naturalFrequency: number; dampingRatio: number; } => {
  if (poles.length < 2) {
    return { naturalFrequency: 0, dampingRatio: 0 };
  }
  
  // For second-order system with complex conjugate poles: s = -ζωₙ ± jωₙ√(1-ζ²)
  const pole = poles[0];
  const naturalFrequency = Math.sqrt(pole.real * pole.real + pole.imaginary * pole.imaginary);
  const dampingRatio = -pole.real / naturalFrequency;
  
  return { 
    naturalFrequency: isFinite(naturalFrequency) ? naturalFrequency : 0,
    dampingRatio: isFinite(dampingRatio) ? dampingRatio : 0
  };
};

// Calculate time domain characteristics
export const calculateTimeCharacteristics = (dampingRatio: number, naturalFrequency: number): {
  peakOvershoot: number;
  settlingTime: number;
  riseTime: number;
} => {
  if (!isFinite(dampingRatio) || !isFinite(naturalFrequency) || naturalFrequency <= 0) {
    return { peakOvershoot: 0, settlingTime: Infinity, riseTime: Infinity };
  }
  
  const peakOvershoot = dampingRatio < 1 ? 
    Math.exp(-Math.PI * dampingRatio / Math.sqrt(1 - dampingRatio * dampingRatio)) * 100 : 0;
  
  const settlingTime = dampingRatio > 0 ? 4 / (dampingRatio * naturalFrequency) : Infinity;
  
  const dampedFreq = naturalFrequency * Math.sqrt(1 - dampingRatio * dampingRatio);
  const riseTime = dampingRatio < 1 && dampedFreq > 0 ? 
    (Math.PI - Math.atan2(Math.sqrt(1 - dampingRatio * dampingRatio), dampingRatio)) / dampedFreq : Infinity;
  
  return { peakOvershoot, settlingTime, riseTime };
};

// Check if system is minimum phase
export const isMinimumPhase = (zeros: Complex[]): boolean => {
  return zeros.every(zero => zero.real <= 0);
};

// Calculate time domain responses
export const calculateTimeResponses = (numCoeffs: number[], denCoeffs: number[]): {
  step: Array<{ time: number; amplitude: number; }>;
  impulse: Array<{ time: number; amplitude: number; }>;
} => {
  const timeEnd = 10;
  const timeStep = 0.1;
  const timePoints = Math.floor(timeEnd / timeStep) + 1;
  
  const step: Array<{ time: number; amplitude: number; }> = [];
  const impulse: Array<{ time: number; amplitude: number; }> = [];
  
  // Simplified time response calculation for up to second-order systems
  const poles = findRoots(denCoeffs);
  const dcGain = calculateDCGain(numCoeffs, denCoeffs);
  
  for (let i = 0; i < timePoints; i++) {
    const t = i * timeStep;
    
    // Step response approximation
    let stepAmp = 0;
    if (poles.length === 1) {
      // First-order system: 1 - e^(-t/τ) where τ = -1/pole
      const tau = -1 / poles[0].real;
      stepAmp = dcGain * (1 - Math.exp(-t / tau));
    } else if (poles.length === 2 && Math.abs(poles[0].imaginary) > 1e-6) {
      // Second-order underdamped system
      const { naturalFrequency, dampingRatio } = calculateSecondOrderParams(poles);
      const dampedFreq = naturalFrequency * Math.sqrt(1 - dampingRatio * dampingRatio);
      const envelope = Math.exp(-dampingRatio * naturalFrequency * t);
      const phase = Math.atan2(Math.sqrt(1 - dampingRatio * dampingRatio), dampingRatio);
      stepAmp = dcGain * (1 - envelope * Math.cos(dampedFreq * t - phase) / Math.sin(phase));
    } else {
      // Default to exponential approach
      stepAmp = dcGain * (1 - Math.exp(-t));
    }
    
    // Impulse response (derivative of step response for simple systems)
    let impulseAmp = 0;
    if (t === 0) {
      impulseAmp = numCoeffs[0] / denCoeffs[0];
    } else if (poles.length === 1) {
      const tau = -1 / poles[0].real;
      impulseAmp = (dcGain / tau) * Math.exp(-t / tau);
    }
    
    step.push({ time: t, amplitude: isFinite(stepAmp) ? stepAmp : 0 });
    impulse.push({ time: t, amplitude: isFinite(impulseAmp) ? impulseAmp : 0 });
  }
  
  return { step, impulse };
};

// Calculate closed loop transfer function T(s) = G(s) / (1 + G(s))
export const calculateClosedLoopTransferFunction = (numCoeffs: number[], denCoeffs: number[]): {
  numerator: number[];
  denominator: number[];
} => {
  // For T(s) = G(s) / (1 + G(s))
  // If G(s) = N(s)/D(s), then T(s) = N(s) / (D(s) + N(s))
  
  // Ensure both polynomials have the same degree by padding with zeros
  const maxDegree = Math.max(numCoeffs.length, denCoeffs.length);
  const paddedNum = [...Array(maxDegree - numCoeffs.length).fill(0), ...numCoeffs];
  const paddedDen = [...Array(maxDegree - denCoeffs.length).fill(0), ...denCoeffs];
  
  // Closed loop numerator is the same as open loop numerator
  const closedLoopNum = [...paddedNum];
  
  // Closed loop denominator is D(s) + N(s)
  const closedLoopDen = paddedDen.map((coeff, index) => coeff + paddedNum[index]);
  
  return {
    numerator: closedLoopNum,
    denominator: closedLoopDen
  };
};

// Calculate complete closed loop analysis
export const analyzeClosedLoopSystem = (numCoeffs: number[], denCoeffs: number[]) => {
  const { numerator: clNum, denominator: clDen } = calculateClosedLoopTransferFunction(numCoeffs, denCoeffs);
  
  const poles = findRoots(clDen);
  const zeros = findRoots(clNum);
  const dcGain = calculateDCGain(clNum, clDen);
  const isStable = isSystemStable(poles);
  
  // Calculate frequency response for closed loop
  const frequencyResponse: Array<{
    frequency: number;
    magnitude: number;
    magnitudeDb: number;
    phase: number;
  }> = [];
  
  const startFreq = 0.01;
  const endFreq = 100;
  const numPoints = 200;
  
  for (let i = 0; i < numPoints; i++) {
    const frequency = startFreq * Math.pow(endFreq / startFreq, i / (numPoints - 1));
    const s = { real: 0, imaginary: frequency };
    
    const numerator = evaluatePolynomial(clNum, s);
    const denominator = evaluatePolynomial(clDen, s);
    const response = complexDivide(numerator, denominator);
    
    const magnitude = complexMagnitude(response);
    const magnitudeDb = 20 * Math.log10(magnitude);
    const phase = complexPhase(response) * 180 / Math.PI;
    
    frequencyResponse.push({
      frequency,
      magnitude,
      magnitudeDb: isFinite(magnitudeDb) ? magnitudeDb : -100,
      phase: isFinite(phase) ? phase : 0
    });
  }
  
  // Calculate closed loop characteristics
  const bandwidth = calculateBandwidth(frequencyResponse);
  const { naturalFrequency, dampingRatio } = calculateSecondOrderParams(poles);
  const { peakOvershoot, settlingTime, riseTime } = calculateTimeCharacteristics(dampingRatio, naturalFrequency);
  const timeResponse = calculateTimeResponses(clNum, clDen);
  
  return {
    poles,
    zeros,
    dcGain,
    isStable,
    frequencyResponse,
    timeResponse,
    bandwidth,
    peakOvershoot,
    settlingTime,
    riseTime
  };
};

// Helper functions for closed loop calculations
const evaluatePolynomial = (coefficients: number[], s: { real: number; imaginary: number; }): { real: number; imaginary: number; } => {
  let result = { real: 0, imaginary: 0 };
  
  for (let i = 0; i < coefficients.length; i++) {
    const power = coefficients.length - 1 - i;
    const term = complexPower(s, power);
    const scaledTerm = complexMultiply(term, { real: coefficients[i], imaginary: 0 });
    result = complexAdd(result, scaledTerm);
  }
  
  return result;
};

const complexAdd = (a: { real: number; imaginary: number; }, b: { real: number; imaginary: number; }): { real: number; imaginary: number; } => ({
  real: a.real + b.real,
  imaginary: a.imaginary + b.imaginary
});

const complexMultiply = (a: { real: number; imaginary: number; }, b: { real: number; imaginary: number; }): { real: number; imaginary: number; } => ({
  real: a.real * b.real - a.imaginary * b.imaginary,
  imaginary: a.real * b.imaginary + a.imaginary * b.real
});

const complexDivide = (a: { real: number; imaginary: number; }, b: { real: number; imaginary: number; }): { real: number; imaginary: number; } => {
  const denominator = b.real * b.real + b.imaginary * b.imaginary;
  return {
    real: (a.real * b.real + a.imaginary * b.imaginary) / denominator,
    imaginary: (a.imaginary * b.real - a.real * b.imaginary) / denominator
  };
};

const complexPower = (base: { real: number; imaginary: number; }, power: number): { real: number; imaginary: number; } => {
  if (power === 0) return { real: 1, imaginary: 0 };
  if (power === 1) return base;
  
  let result = { real: 1, imaginary: 0 };
  for (let i = 0; i < power; i++) {
    result = complexMultiply(result, base);
  }
  return result;
};

const complexMagnitude = (c: { real: number; imaginary: number; }): number => 
  Math.sqrt(c.real * c.real + c.imaginary * c.imaginary);

const complexPhase = (c: { real: number; imaginary: number; }): number => 
  Math.atan2(c.imaginary, c.real);