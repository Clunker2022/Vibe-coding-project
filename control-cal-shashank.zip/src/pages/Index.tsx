import ControlCalculator from '@/components/ControlCalculator';

const Index = () => {
  return <ControlCalculator />;
};

export default Index;
